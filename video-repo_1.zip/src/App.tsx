import type { Component } from 'solid-js';
import TVideo  from './tvideo';




const App: Component = () => {
  return (
    <div >
      <TVideo/>
    </div>
  );
};

export default App;
